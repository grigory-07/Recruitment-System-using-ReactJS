**CAMPUS RECTUITMENT SYSTEM.**

**TECHNOLOGIES/LIABRARY/FRAMEWORKS USED IN IT:**
ReactJs
React-bootstrap
Firebase
Formik
Yup

**Testing credentials:**
Email: company1@gmail.com
Pass:   111111

Email:  student2@gmail.com
Pass:   111111


**Live web URL:**
https://campus-recruitment-syste-2c8e3.web.app/

**How to use run it locally:**
Run following command in your terminal
git clone https://github.com/MrFarhan/Campus-Recruitment-System-using-ReactJS
yarn install
yarn start
