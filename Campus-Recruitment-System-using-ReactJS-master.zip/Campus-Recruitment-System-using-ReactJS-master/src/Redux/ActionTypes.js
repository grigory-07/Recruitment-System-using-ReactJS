export const CURRENT_USER = "CURRENT_USER";
export const ALL_USERS = "ALL_USERS";
export const IS_LOADING = "IS_LOADING";
export const ALL_JOBS = "ALL_JOBS";
export const APPLIED_JOBS = "APPLIED_JOBS";

